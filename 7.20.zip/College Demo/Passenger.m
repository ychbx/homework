//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"


@implementation Orders

@end

@implementation Passenger

-(bool) reserve:(NSMutableArray*) n_list : NSString ID ｛
	for(id obj in n_list){
		if([obj isEqualToString: ID])
			return NO;
	}
	[n_list addObject: ID];
	return YES;
｝
-(bool) check:(NSMutableArray*) n_list :(NSMutableArray*) h_list : NSString ID｛	
	for(id obj in n_list){
		if([obj isEqualToString: ID])
		{
			[n_list removeObject: ID];
			[h_list addObject: ID];
			return YES;
		}
	}
	return NO;
｝
@end
