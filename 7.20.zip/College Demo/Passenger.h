//
//  Passenger.h
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Orders : NSObject

@end

@interface Passenger : Person 

@property(nonatomic, readonly, assign) bool age;
@property(nonatomic, readonly, assign) NSMutableArray *h_list = [NSMutableArray array];
@property(nonatomic, assign) NSMutableArray *n_list = [NSMutableArray array];

-(bool)reserve:(NSMutableArray*)n_list : NSString ID;
-(bool)check:(NSMutableArray*)n_list : (NSMutableArray*)h_list : NSString ID;
// @property 属性
// 是否年满 18 岁

// 历史订单 （数组）
// 未出行订单 （数组）

// Function 方法
// 去订票

// 去检票
@end

NS_ASSUME_NONNULL_END
